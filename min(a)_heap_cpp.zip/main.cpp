#include "testtreiber.hpp"

int main() {
    Testtreiber::execute_tests();
}